<?php echo e($slot); ?>

<?php /**PATH C:\Users\jonat\OneDrive\Universidad\Tesis\Proyecto\ds-bspi-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
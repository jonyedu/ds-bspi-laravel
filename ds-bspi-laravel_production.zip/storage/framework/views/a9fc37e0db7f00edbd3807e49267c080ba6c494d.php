<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-md-offset-4 well">
    <center>
        <form method="POST" action="<?php echo e(route('password.update')); ?>">
            <?php echo csrf_field(); ?>
            <div
                style="position:absolute; top:0; left:68%;"
                class="text-left col-lg-4 col-md-4 col-sm-12"
            >
                <div
                    class="alert alert-success alert-dismissible fade show"
                    role="alert"
                >
                    <strong
                        >La contraseña debe cumplir con los siguientes
                        puntos:</strong
                    >
                    <br />
                    <span>*Minimo 8 y Maximo 12 Caracteres</span>
                    <br />
                    <span>*Caracteres en mayúscula (A - Z)</span>
                    <br />
                    <span>*Caracteres en minúscula (a - z)</span>
                    <br />
                    <span>*Base 10 dígitos (0 - 9)</span>
                    <br />
                    <span>*Caracteres especiales (-@$!%*#?&)</span>
                </div>
            </div>
            <div class="col-md-7 col-md-offset-4 well" style="margin-top: 5%;">
                <div class="row">
                    <!-- Logo -->
                    <div class="col-md-12 text-center">
                        <img style="margin-top: 5%;" alt="Hospital" src="/images/hospital.png">
                    </div>
                    <!-- Campo Token Oculto-->
                    <div class="col-md-12 text-center">
                        <input type="hidden" name="token" value="<?php echo e($token); ?>">
                    </div>
                    <!-- Formulario -->
                    <br>
                    <div class="col-md-12 text-center">
                        <div class="row">
                            <!-- Correo Electrónico -->
                            <div class="col-12">
                                <div class="form-group row">
                                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo Electrónico')); ?></label>
                                    <div class="col-md-6">
                                        <div class="input-group mb-3">
                                            <input placeholder="Correo Electrónico" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autocomplete="email" autofocus>
                                            <div class="input-group-append">
                                                <div class="input-group-text">
                                                    <span class="fas fa-envelope"></span>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Password -->
                            <div class="col-12">
                                <div class="form-group row">
                                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>
                                    <div class="col-md-6">
                                        <div class="input-group mb-3">
                                            <input placeholder="Contraseña" id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php if( $message != 'El campo de confirmación de password no coincide.'): ?> is-invalid <?php endif; ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                                            <div class="input-group-append">
                                                <div class="input-group-text">
                                                    <span id="fast" class="fas fa-eye" onclick="mostrarContrasena(1)"></span>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php if($message != "El campo de confirmación de password no coincide."): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Confirmar Password -->
                            <div class="col-12">
                                <div class="form-group row">
                                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirmar Contraseña')); ?></label>
                                    <div class="col-md-6">
                                        <div class="input-group mb-3">
                                            <input placeholder="Confirmar Contraseña" id="password-confirm" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php if($message == 'El campo de confirmación de password no coincide.'): ?> is-invalid <?php endif; ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" required autocomplete="new-password">
                                            <div class="input-group-append">
                                                <div class="input-group-text">
                                                    <span id="fastCon" class="fas fa-eye" onclick="mostrarContrasena(0)"></span>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php if($message == "El campo de confirmación de password no coincide."): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Boton Restablecer Clave -->
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Restablecer Contraseña')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <br>
            </div>
        </form>
    </center>
</div>
<script>
    function mostrarContrasena(opc) {
        if (opc) {
            var tipo = document.getElementById("password");
            var fast = document.getElementById("fast");
            if (tipo.type == "password") {
                tipo.type = "text";
                fast.className = "fa fa-eye-slash";
            } else {
                tipo.type = "password";
                fast.className = "fas fa-eye";
            }
        } else {
            var tipo1 = document.getElementById("password-confirm");
            var fastCon = document.getElementById("fastCon");
            if (tipo1.type == "password") {
                tipo1.type = "text";
                fastCon.className = "fa fa-eye-slash";
            } else {
                tipo1.type = "password";
                fastCon.className = "fas fa-eye";
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jonat\OneDrive\Universidad\Tesis\Proyecto\ds-bspi-laravel\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>
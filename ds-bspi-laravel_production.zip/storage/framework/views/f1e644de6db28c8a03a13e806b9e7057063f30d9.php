<?php $__env->startSection('content'); ?>
    <app :user="<?php echo e(json_encode(Auth::user())); ?>"></app>              
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jonat\OneDrive\Universidad\Tesis\Proyecto\ds-bspi-laravel\resources\views/datosGenerales/generalidades/configuracionGeneralidades.blade.php ENDPATH**/ ?>
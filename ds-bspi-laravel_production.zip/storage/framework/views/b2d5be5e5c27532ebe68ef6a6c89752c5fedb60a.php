<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-md-8 hidden-xs hidden-sm cover container-cover">
        <div>
            <img style="margin-top: -2%; position: fixed; z-index: -99; width: 62%; height: 105%" src="/images/hospital_2017.jpg" alt="Logo">
        </div>

    </div>
    <div style="position: absolute;top: 50%;left: 95%;height: 30%;width: 50%;margin: -15% 0 0 -25%;" class="col-md-3 hidden-xs hidden-sm cover container-cover">
        <img style="display:block;margin:auto;" src="/images/hospital.png" alt="Logo">
        <br>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <center style="clear : all;font-family: fantasy;font-size: 16pt;">Ingrese a su cuenta</center>
            <br>
            <div class="row">
                <div class="col-12">
                    <!-- Identificacion -->
                    <div class="input-group mb-3">
                        <input id="US_COD" placeholder="Identificacion" type="text" class="form-control <?php $__errorArgs = ['US_COD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="US_COD" value="<?php echo e(old('US_COD')); ?>" required autocomplete="US_COD" autofocus>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['US_COD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Clave -->
                <div class="col-12">
                    <div class="input-group mb-3">
                        <input id="password" placeholder="Contraseña" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span id="fast" class="fas fa-eye" onclick="mostrarContrasena()"></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Boton Iniciar Sesión -->
                <div class="col-12">
                    <button id="password" type="submit" class="btn btn-primary btn-block"><?php echo e(__('Iniciar Sesión')); ?></button>
                </div>
                <!-- Label ¿Olvidó su contraseña? -->
                <div class="col-12" align="center">
                    <div class="icheck-primary">
                        <?php if(Route::has('password.request')): ?>
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('¿Olvidó su contraseña?')); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    function mostrarContrasena() {
        var tipo = document.getElementById("password");
        var fast = document.getElementById("fast");
        if (tipo.type == "password") {
            tipo.type = "text";
            fast.className = "fa fa-eye-slash";            
        } else {
            tipo.type = "password";
            fast.className = "fas fa-eye";
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jonat\OneDrive\Universidad\Tesis\Proyecto\ds-bspi-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>
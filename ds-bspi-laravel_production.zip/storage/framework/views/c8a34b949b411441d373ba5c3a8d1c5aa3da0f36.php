<tr>
<td class="header">
<a href="<?php echo e($url); ?>">
<?php echo e($slot); ?>

</a>
</td>
</tr>
<?php /**PATH C:\Users\jonat\OneDrive\Universidad\Tesis\Proyecto\ds-bspi-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php ENDPATH**/ ?>
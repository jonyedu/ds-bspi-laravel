<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-md-offset-4 well">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <center>
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="col-md-4 col-md-offset-4 well" style="margin-top: 5%;background-color:#EEEEEE;">
                <div class="col-md-12 text-center">
                    <img style="margin-top: 5%;" alt="Hospital" src="/images/hospital.png">
                </div>
                <br>
                <p style="text-align:center;">
                    Por favor ingrese su correo electrónico. Recibirá las instrucciones para obtener su nueva contraseña.
                </p>
                <form name="claveForm" method="POST">
                    <div class="input-group mb-3">
                        <input placeholder="Correo Electrónico" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group row mb-0">
                        <div class="col-md-12" align="center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Enviar enlace de restablecimiento')); ?>

                            </button>
                        </div>
                    </div>
                </form>

                <br>
                <div class="row">
                    <div class="col-12" align="center">
                        <div class="icheck-primary">
                            <?php if(Route::has('login')): ?>
                            <a class="btn btn-link" href="<?php echo e(route('login')); ?>">
                                <?php echo e(__('Iniciar Sesión')); ?>

                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </center>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jonat\OneDrive\Universidad\Tesis\Proyecto\ds-bspi-laravel\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers\GestionHospitalaria\Pacientes;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
class PacienteApiController extends Controller
{
    //
}

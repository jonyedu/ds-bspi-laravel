ALTER TABLE `siemprea_bspi_gestion_hospitalaria`.`diagnosticos` 
DROP INDEX `diagnosticos_diagnostico_nom_unique` ;
;
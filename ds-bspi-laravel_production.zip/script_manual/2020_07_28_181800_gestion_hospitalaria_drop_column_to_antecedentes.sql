ALTER TABLE `siemprea_bspi_gestion_hospitalaria`.`antecedentes` 
DROP COLUMN `ANTECEDENTE_EVOLUCION`;
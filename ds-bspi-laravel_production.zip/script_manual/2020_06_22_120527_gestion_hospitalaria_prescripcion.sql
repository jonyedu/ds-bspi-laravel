CREATE TABLE `siemprea_bspi_gestion_hospitalaria`.`prescripcion` (
  `PRESCRIPCION_COD` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `DOCTOR_COD` BIGINT UNSIGNED NOT NULL,
  `HOSPITAL_COD` BIGINT UNSIGNED NOT NULL,
  `PACIENTE_COD` BIGINT UNSIGNED NOT NULL,
  `CITA_COD` BIGINT UNSIGNED NOT NULL,
  `PRESCRIPCION_FCHA_CTUAL` DATE NOT NULL,
  `PRESCRIPCION_LOGIC_ESTADO` CHAR(2) NOT NULL,
  `US_COD_CREATED_UPDATED` VARCHAR(10) NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`PRESCRIPCION_COD`));

ALTER TABLE `siemprea_bspi_gestion_hospitalaria`.`prescripcion` 
ADD INDEX `prescripcion_cita_cod_foreing_idx` (`CITA_COD` ASC) VISIBLE;
;
ALTER TABLE `siemprea_bspi_gestion_hospitalaria`.`prescripcion` 
ADD CONSTRAINT `prescripcion_cita_cod_foreing`
  FOREIGN KEY (`CITA_COD`)
  REFERENCES `siemprea_bspi_gestion_hospitalaria`.`citas` (`CITA_COD`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;

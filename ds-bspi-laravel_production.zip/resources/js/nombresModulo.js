export const nombresModulo = {
    datos_generales: "DatosGenerales",
    gestion_hospitalaria: "GestionHospitalaria"
};

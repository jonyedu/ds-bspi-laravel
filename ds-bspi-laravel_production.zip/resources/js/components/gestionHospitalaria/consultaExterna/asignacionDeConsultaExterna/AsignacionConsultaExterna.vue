<template>
    <admisiones :titulo="'Consulta Externa'" :es-consulta-externa="true" :es-admision="false"></admisiones>
</template>
<template>
    <div>
        <h1>Imageneologica</h1>
    </div>
</template>
<?php

namespace App\Http\Controllers\DatosGenerales\Generalidades;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IdentificacionesYUsuarioApiController extends Controller
{
    //
}

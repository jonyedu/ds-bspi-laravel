<template>
    <div>
        <h1>LaboratorioClinico</h1>
    </div>
</template>
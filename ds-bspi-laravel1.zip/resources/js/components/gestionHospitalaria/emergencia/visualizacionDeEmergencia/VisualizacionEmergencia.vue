<template>
    <lista-emergencia :seleccionar-button="false"></lista-emergencia>
</template>
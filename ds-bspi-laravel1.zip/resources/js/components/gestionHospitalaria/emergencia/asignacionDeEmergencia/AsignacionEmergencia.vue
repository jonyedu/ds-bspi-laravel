<template>
    <admisiones :titulo="'Emergencia'" :es-consulta-externa="false" :es-emergencia="true" :es-admision="false"></admisiones>
</template>
<template>
   
</template>
<script>
export default {
  data: function() {
    return {
      form: {
        
      }
    };
  },
  mounted: function() {
    // this.cargarConfiguraciones();
    // let nombreModulo = this.$nombresModulo.datos_generales;
    // let nombreFormulario = this.$nombresFormulario.datos_generales.generalidades
    //   .configuracion_generalidades.nombre_formulario;
    // this.$funcionesGlobales.registrarLogForm(
    //   nombreModulo,
    //   nombreFormulario,
    //   "Ingreso"
    // );
  },
  beforeDestroy: function() {
    // let nombreModulo = this.$nombresModulo.datos_generales;
    // let nombreFormulario = this.$nombresFormulario.datos_generales.generalidades
    //   .configuracion_generalidades.nombre_formulario;
    // this.$funcionesGlobales.registrarLogForm(
    //   nombreModulo,
    //   nombreFormulario,
    //   "Salida"
    // );
  },

  methods: {
   
  }
};
</script>

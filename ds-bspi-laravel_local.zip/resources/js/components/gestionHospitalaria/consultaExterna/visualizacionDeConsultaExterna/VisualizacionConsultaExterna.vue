<template>
    <lista-cita-consulta-externa :seleccionar-button="false"></lista-cita-consulta-externa>
</template>